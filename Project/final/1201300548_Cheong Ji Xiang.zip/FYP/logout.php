<?php
session_start();
unset($_SESSION['name']);

echo"You have Log out!! Goodbye"
?>