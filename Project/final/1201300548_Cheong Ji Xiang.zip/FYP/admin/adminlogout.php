<?php
session_start();
unset($_SESSION['name1']);

echo"You have Log out!! Goodbye"
?>