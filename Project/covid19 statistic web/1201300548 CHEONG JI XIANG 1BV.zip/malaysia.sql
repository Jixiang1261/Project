-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 27, 2022 at 10:27 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `malaysia`
--

-- --------------------------------------------------------

--
-- Table structure for table `johor`
--

CREATE TABLE `johor` (
  `DateTime` date DEFAULT NULL,
  `DeathCases` int(10) DEFAULT NULL,
  `ConfirmedCases` int(10) DEFAULT NULL,
  `HospitalAdmissions` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `johor`
--

INSERT INTO `johor` (`DateTime`, `DeathCases`, `ConfirmedCases`, `HospitalAdmissions`) VALUES
('2022-03-16', 11, 2577, 298),
('2022-03-17', 10, 1990, 313),
('2022-03-18', 14, 1624, 317),
('2022-03-19', 11, 1286, 249),
('2022-03-20', 10, 1441, 255),
('2022-03-21', 2, 1088, 297),
('2022-03-22', 0, 927, 270);

-- --------------------------------------------------------

--
-- Table structure for table `kedah`
--

CREATE TABLE `kedah` (
  `Datetime` date DEFAULT NULL,
  `DeathCases` int(10) DEFAULT NULL,
  `ConfirmedCases` int(10) DEFAULT NULL,
  `HospitalAdmissions` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kedah`
--

INSERT INTO `kedah` (`Datetime`, `DeathCases`, `ConfirmedCases`, `HospitalAdmissions`) VALUES
('2022-03-16', 10, 2034, 125),
('2022-03-17', 6, 1916, 162),
('2022-03-18', 10, 1529, 113),
('2022-03-19', 5, 1353, 105),
('2022-03-20', 5, 1113, 110),
('2022-03-21', 1, 1402, 99),
('2022-03-22', 0, 1219, 106);

-- --------------------------------------------------------

--
-- Table structure for table `kelantan`
--

CREATE TABLE `kelantan` (
  `Datetime` date DEFAULT NULL,
  `DeathCases` int(10) DEFAULT NULL,
  `ConfirmedCases` int(10) DEFAULT NULL,
  `HospitalAdmissions` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kelantan`
--

INSERT INTO `kelantan` (`Datetime`, `DeathCases`, `ConfirmedCases`, `HospitalAdmissions`) VALUES
('2022-03-16', 3, 995, 157),
('2022-03-17', 2, 863, 107),
('2022-03-18', 2, 625, 127),
('2022-03-19', 2, 540, 117),
('2022-03-20', 1, 518, 83),
('2022-03-21', 0, 608, 100),
('2022-03-22', 0, 609, 105);

-- --------------------------------------------------------

--
-- Table structure for table `kl`
--

CREATE TABLE `kl` (
  `Datetime` date DEFAULT NULL,
  `DeathCases` int(10) DEFAULT NULL,
  `ConfirmedCases` int(10) DEFAULT NULL,
  `HospitalAdmissions` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kl`
--

INSERT INTO `kl` (`Datetime`, `DeathCases`, `ConfirmedCases`, `HospitalAdmissions`) VALUES
('2022-03-16', 1, 3565, 120),
('2022-03-17', 1, 3266, 112),
('2022-03-18', 1, 2757, 120),
('2022-03-19', 2, 3078, 125),
('2022-03-20', 0, 1659, 77),
('2022-03-21', 2, 1433, 91),
('2022-03-22', 2, 3433, 115);

-- --------------------------------------------------------

--
-- Table structure for table `klang`
--

CREATE TABLE `klang` (
  `Datetime` date DEFAULT NULL,
  `DeathCases` int(10) DEFAULT NULL,
  `ConfirmedCases` int(10) DEFAULT NULL,
  `HospitalAdmissions` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `klang`
--

INSERT INTO `klang` (`Datetime`, `DeathCases`, `ConfirmedCases`, `HospitalAdmissions`) VALUES
('2022-03-16', 23, 11306, 606),
('2022-03-17', 7, 10974, 585),
('2022-03-18', 8, 10329, 632),
('2022-03-19', 17, 10572, 522),
('2022-03-20', 8, 8553, 439),
('2022-03-21', 0, 8474, 456),
('2022-03-22', 0, 10950, 493);

-- --------------------------------------------------------

--
-- Table structure for table `labuan`
--

CREATE TABLE `labuan` (
  `Datetime` date DEFAULT NULL,
  `DeathCases` int(10) DEFAULT NULL,
  `ConfirmedCases` int(10) DEFAULT NULL,
  `HospitalAdmissions` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `labuan`
--

INSERT INTO `labuan` (`Datetime`, `DeathCases`, `ConfirmedCases`, `HospitalAdmissions`) VALUES
('2022-03-16', 1, 146, 2),
('2022-03-17', 0, 131, 5),
('2022-03-18', 0, 83, 3),
('2022-03-19', 0, 72, 2),
('2022-03-20', 0, 87, 4),
('2022-03-21', 0, 72, 8),
('2022-03-22', 1, 93, 4);

-- --------------------------------------------------------

--
-- Table structure for table `melaka`
--

CREATE TABLE `melaka` (
  `Datetime` date DEFAULT NULL,
  `DeathCases` int(10) DEFAULT NULL,
  `ConfirmedCases` int(10) DEFAULT NULL,
  `HospitalAdmissions` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `melaka`
--

INSERT INTO `melaka` (`Datetime`, `DeathCases`, `ConfirmedCases`, `HospitalAdmissions`) VALUES
('2022-03-16', 4, 727, 60),
('2022-03-17', 5, 750, 42),
('2022-03-18', 1, 645, 60),
('2022-03-19', 2, 639, 34),
('2022-03-20', 2, 508, 59),
('2022-03-21', 0, 422, 33),
('2022-03-22', 0, 536, 57);

-- --------------------------------------------------------

--
-- Table structure for table `pahang`
--

CREATE TABLE `pahang` (
  `Datetime` date DEFAULT NULL,
  `DeathCases` int(10) DEFAULT NULL,
  `ConfirmedCases` int(10) DEFAULT NULL,
  `HospitalAdmissions` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pahang`
--

INSERT INTO `pahang` (`Datetime`, `DeathCases`, `ConfirmedCases`, `HospitalAdmissions`) VALUES
('2022-03-16', 4, 1302, 122),
('2022-03-17', 1, 1434, 127),
('2022-03-18', 3, 1000, 105),
('2022-03-19', 1, 1009, 106),
('2022-03-20', 4, 1100, 97),
('2022-03-21', 0, 771, 67),
('2022-03-22', 1, 959, 75);

-- --------------------------------------------------------

--
-- Table structure for table `perak`
--

CREATE TABLE `perak` (
  `Datetime` date DEFAULT NULL,
  `DeathCases` int(10) DEFAULT NULL,
  `ConfirmedCases` int(10) DEFAULT NULL,
  `HospitalAdmissions` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `perak`
--

INSERT INTO `perak` (`Datetime`, `DeathCases`, `ConfirmedCases`, `HospitalAdmissions`) VALUES
('2022-03-16', 9, 1446, 200),
('2022-03-17', 18, 1561, 195),
('2022-03-18', 11, 1703, 197),
('2022-03-19', 9, 1403, 174),
('2022-03-20', 9, 1300, 150),
('2022-03-21', 12, 1015, 139),
('2022-03-22', 8, 1170, 152);

-- --------------------------------------------------------

--
-- Table structure for table `perlis`
--

CREATE TABLE `perlis` (
  `Datetime` date DEFAULT NULL,
  `DeathCases` int(10) DEFAULT NULL,
  `ConfirmedCases` int(10) DEFAULT NULL,
  `HospitalAdmissions` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `perlis`
--

INSERT INTO `perlis` (`Datetime`, `DeathCases`, `ConfirmedCases`, `HospitalAdmissions`) VALUES
('2022-03-16', 0, 159, 30),
('2022-03-17', 0, 171, 32),
('2022-03-18', 0, 128, 28),
('2022-03-19', 0, 123, 27),
('2022-03-20', 1, 90, 20),
('2022-03-21', 1, 104, 19),
('2022-03-22', 2, 131, 25);

-- --------------------------------------------------------

--
-- Table structure for table `pinang`
--

CREATE TABLE `pinang` (
  `Datetime` date DEFAULT NULL,
  `DeathCases` int(10) DEFAULT NULL,
  `ConfirmedCases` int(10) DEFAULT NULL,
  `HospitalAdmissions` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pinang`
--

INSERT INTO `pinang` (`Datetime`, `DeathCases`, `ConfirmedCases`, `HospitalAdmissions`) VALUES
('2022-03-16', 3, 2441, 157),
('2022-03-17', 5, 2315, 173),
('2022-03-18', 6, 2306, 142),
('2022-03-19', 2, 1928, 136),
('2022-03-20', 4, 1772, 135),
('2022-03-21', 2, 1310, 128),
('2022-03-22', 2, 1295, 112);

-- --------------------------------------------------------

--
-- Table structure for table `putrajaya`
--

CREATE TABLE `putrajaya` (
  `Datetime` date DEFAULT NULL,
  `DeathCases` int(10) DEFAULT NULL,
  `ConfirmedCases` int(10) DEFAULT NULL,
  `HospitalAdmissions` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `putrajaya`
--

INSERT INTO `putrajaya` (`Datetime`, `DeathCases`, `ConfirmedCases`, `HospitalAdmissions`) VALUES
('2022-03-16', 1, 180, 39),
('2022-03-17', 0, 150, 42),
('2022-03-18', 0, 142, 57),
('2022-03-19', 0, 128, 36),
('2022-03-20', 0, 133, 30),
('2022-03-21', 0, 100, 43),
('2022-03-22', 0, 65, 28);

-- --------------------------------------------------------

--
-- Table structure for table `sabah`
--

CREATE TABLE `sabah` (
  `Datetime` date DEFAULT NULL,
  `DeathCases` int(10) DEFAULT NULL,
  `ConfirmedCases` int(10) DEFAULT NULL,
  `HospitalAdmissions` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sabah`
--

INSERT INTO `sabah` (`Datetime`, `DeathCases`, `ConfirmedCases`, `HospitalAdmissions`) VALUES
('2022-03-16', 0, 708, 124),
('2022-03-17', 4, 769, 107),
('2022-03-18', 0, 596, 96),
('2022-03-19', 1, 421, 101),
('2022-03-20', 4, 339, 61),
('2022-03-21', 0, 416, 77),
('2022-03-22', 1, 402, 93);

-- --------------------------------------------------------

--
-- Table structure for table `sarawak`
--

CREATE TABLE `sarawak` (
  `Datetime` date DEFAULT NULL,
  `DeathCases` int(10) DEFAULT NULL,
  `ConfirmedCases` int(10) DEFAULT NULL,
  `HospitalAdmissions` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sarawak`
--

INSERT INTO `sarawak` (`Datetime`, `DeathCases`, `ConfirmedCases`, `HospitalAdmissions`) VALUES
('2022-03-16', 4, 1555, 169),
('2022-03-17', 3, 1484, 162),
('2022-03-18', 1, 1316, 148),
('2022-03-19', 4, 1177, 162),
('2022-03-20', 2, 852, 123),
('2022-03-21', 1, 813, 127),
('2022-03-22', 2, 1547, 153);

-- --------------------------------------------------------

--
-- Table structure for table `selangor`
--

CREATE TABLE `selangor` (
  `Datetime` date DEFAULT NULL,
  `DeathCases` int(10) DEFAULT NULL,
  `ConfirmedCases` int(10) DEFAULT NULL,
  `HospitalAdmissions` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `selangor`
--

INSERT INTO `selangor` (`Datetime`, `DeathCases`, `ConfirmedCases`, `HospitalAdmissions`) VALUES
('2022-03-16', 21, 7561, 447),
('2022-03-17', 6, 7558, 431),
('2022-03-18', 7, 7430, 455),
('2022-03-19', 16, 7366, 361),
('2022-03-20', 10, 6761, 332),
('2022-03-21', 7, 6941, 322),
('2022-03-22', 9, 7452, 350);

-- --------------------------------------------------------

--
-- Table structure for table `sembilan`
--

CREATE TABLE `sembilan` (
  `Datetime` date DEFAULT NULL,
  `DeathCases` int(10) DEFAULT NULL,
  `ConfirmedCases` int(10) DEFAULT NULL,
  `HospitalAdmissions` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sembilan`
--

INSERT INTO `sembilan` (`Datetime`, `DeathCases`, `ConfirmedCases`, `HospitalAdmissions`) VALUES
('2022-03-16', 3, 1968, 99),
('2022-03-17', 5, 1882, 105),
('2022-03-18', 1, 1502, 96),
('2022-03-19', 3, 1405, 104),
('2022-03-20', 1, 885, 75),
('2022-03-21', 1, 595, 55),
('2022-03-22', 2, 1061, 87);

-- --------------------------------------------------------

--
-- Table structure for table `terengganu`
--

CREATE TABLE `terengganu` (
  `Datetime` date DEFAULT NULL,
  `DeathCases` int(10) DEFAULT NULL,
  `ConfirmedCases` int(10) DEFAULT NULL,
  `HospitalAdmissions` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `terengganu`
--

INSERT INTO `terengganu` (`Datetime`, `DeathCases`, `ConfirmedCases`, `HospitalAdmissions`) VALUES
('2022-03-16', 3, 934, 88),
('2022-03-17', 1, 764, 78),
('2022-03-18', 2, 853, 66),
('2022-03-19', 1, 413, 58),
('2022-03-20', 2, 547, 70),
('2022-03-21', 3, 738, 78),
('2022-03-22', 0, 584, 62);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
