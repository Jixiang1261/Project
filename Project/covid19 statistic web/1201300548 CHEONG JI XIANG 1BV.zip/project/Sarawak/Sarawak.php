<!DOCTYPE html>
<html>
<head>
     <title>Sarawak</title>
     <style type=text/css>
      .bold {
		  font-weight: bold;
		  font-size: 20px;
		  }
		  
	  .other{
		  font-size: 20px;
		  }
	  
	  table, th, td {
      border: 3px solid black;
      }
	  
	   h1 {
	   font-size: 60px;
	   color:blue;
       }
	  
	   h2 {
	   font-size: 30px;
	   color:blue;
       }
	   
       #myChart {
       position: absolute;
       left: 50%;
       top: 5%;
	   }

       #myChart1 {
       position: absolute;
       left: 50%;
       top: 40%;
	   }

       #myChart2 {
       position: absolute;
       left: 50%;
       top: 75%;
	   }

     </style>
	 <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
</head>

<body>
   <?php
    //connect to database
	$cont = mysqli_connect('localhost', 'root', '');
	
   	//ii check
	if(!$cont){
		  echo("error");
	}
	
	//select database
	if(!(mysqli_select_db($cont, "malaysia"))){
		  echo("error2");
	}
	
	//select all
   $query = "SELECT * FROM sarawak";
   
   	if(!($result = mysqli_query($cont, $query))){
		  echo("Failed to run command");
	}
	echo "<h1>The Status of Sarawak</h1>";
		echo "<table>";
		echo "<tr>
	         <td style='text-align:center' class=\"bold\">Date:</td>
	         <td style='text-align:center' class=\"bold\">Death Cases:</td>
			 <td style='text-align:center' class=\"bold\">Confirmed Cases:</td>
			 <td style='text-align:center' class=\"bold\">Hospital Admission:</td>
		 </tr>";
    while ($row = mysqli_fetch_row($result)){
	
	$row[3]=str_replace("<br>","\n",$row[3]);

		 
	echo "<tr>
	      <td style='text-align:center' class=\"other\">$row[0]</td>  
          <td style='text-align:center' class=\"other\">$row[1]</td>	
          <td style='text-align:center' class=\"other\">$row[2]</td>
          <td style='text-align:center' class=\"other\">$row[3]</td>		  
	     </tr>";
		 

    } 
	echo "</table>";
	mysqli_close($cont);
   ?>
   
   <a href="admin.html"><h2>Edit the Data</h2></a>
   <a href="..\east.html"><h2>Back to East Malaysia</h2></a>
   <a href="..\index.html"><h2>Back to Main Page</h2></a>

<canvas id="myChart" style="width:100%;max-width:600px"></canvas>
<canvas id="myChart1" style="width:100%;max-width:600px"></canvas>
<canvas id="myChart2" style="width:100%;max-width:600px"></canvas>
<script>
  var xValues = ["2022-03-16", "2022-03-17", "2022-03-18", "2022-03-19", "2022-03-20", "2022-03-21", "2022-03-22"];
  var yValues = [4, 3, 1, 4, 2, 1, 2];
  var barColors = "red";

  new Chart("myChart", {
    type: "bar",
    data: {
    labels: xValues,
    datasets: [{
      backgroundColor: barColors,
      data: yValues
    }]},
    options: {
    legend: {display: false},
    title: {display: true,
     text: "Death Cases in Sarawak:"
 }}});

  var xValues = ["2022-03-16", "2022-03-17", "2022-03-18", "2022-03-19", "2022-03-20", "2022-03-21", "2022-03-22"];
  var yValues = [1555, 1484, 1316, 1177, 852, 813, 1547];
  var barColors = "blue";

  new Chart("myChart1", {
    type: "bar",
    data: {
    labels: xValues,
    datasets: [{
      backgroundColor: barColors,
      data: yValues
    }]},
    options: {
    legend: {display: false},
    title: {display: true,
     text: "Confirmed Cases in Sarawak:"
 }}});

  var xValues = ["2022-03-16", "2022-03-17", "2022-03-18", "2022-03-19", "2022-03-20", "2022-03-21", "2022-03-22"];
  var yValues = [169, 162, 148, 162, 123, 127, 153];
  var barColors = "green";

  new Chart("myChart2", {
    type: "bar",
    data: {
    labels: xValues,
    datasets: [{
      backgroundColor: barColors,
      data: yValues
    }]},
    options: {
    legend: {display: false},
    title: {display: true,
     text: "Hospital Admission in Sarawak:"
 }}});

</script>
</body>

</html>